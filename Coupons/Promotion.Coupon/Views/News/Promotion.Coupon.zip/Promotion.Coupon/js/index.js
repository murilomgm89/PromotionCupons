function validateForm() {
  var name = document.forms["intimus"]["fname"]
  var mail = document.forms["intimus"]["email"]
  var cpf = document.forms["intimus"]["cpf"]

  var nameValue = document.forms["intimus"]["fname"].value;
  var mailValue = document.forms["intimus"]["email"].value;
  var cpfValue = document.forms["intimus"]["cpf"].value;

  if (nameValue == "" || nameValue < 3) {
    name.classList.add("error");
    return false;
  }
  if (cpfValue !== "" || cpfValue !== undefined) {
  	cpf.classList.add("error");
  	return false;
  }
}


var modal = document.querySelector("#modal");
var modalOverlay = document.querySelector("#modal-overlay");
var closeButton = document.querySelector("#close-button");
var openButtonFooter = document.querySelector("#open-button-footer");
var openButtonForm = document.querySelector("#open-button-form");

openButtonFooter.addEventListener("click", function() {
  modal.classList.toggle("open");
  modalOverlay.classList.toggle("open");
});
openButtonForm.addEventListener("click", function() {
  modal.classList.toggle("open");
  modalOverlay.classList.toggle("open");
});

closeButton.addEventListener("click", function() {
  modal.classList.toggle("open");
  modalOverlay.classList.toggle("open");
});